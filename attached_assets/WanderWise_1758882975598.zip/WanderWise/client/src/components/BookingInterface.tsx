import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { 
  CreditCard, 
  Shield, 
  Calendar, 
  Users, 
  MapPin, 
  IndianRupee,
  Check,
  Clock,
  Phone,
  Mail
} from "lucide-react";
import { useState } from "react";

interface BookingItem {
  id: string;
  type: 'accommodation' | 'transport' | 'activity';
  name: string;
  details: string;
  cost: number;
  date: string;
  selected: boolean;
}

interface BookingInterfaceProps {
  items: BookingItem[];
  totalAmount: number;
  onBook?: (selectedItems: string[], paymentMethod: string) => void;
}

export default function BookingInterface({ items, totalAmount, onBook }: BookingInterfaceProps) {
  const [selectedItems, setSelectedItems] = useState<string[]>(
    items.filter(item => item.selected).map(item => item.id)
  );
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleItemToggle = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const selectedTotal = items
    .filter(item => selectedItems.includes(item.id))
    .reduce((sum, item) => sum + item.cost, 0);

  const handleBooking = async () => {
    setIsProcessing(true);
    console.log("Processing booking:", { selectedItems, paymentMethod, total: selectedTotal });
    
    // Simulate booking process
    setTimeout(() => {
      setIsProcessing(false);
      onBook?.(selectedItems, paymentMethod);
    }, 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Booking Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Booking Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold">{selectedItems.length}</p>
              <p className="text-sm text-muted-foreground">Items Selected</p>
            </div>
            <div>
              <p className="text-2xl font-bold">7</p>
              <p className="text-sm text-muted-foreground">Total Days</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">
                ₹{selectedTotal.toLocaleString('en-IN')}
              </p>
              <p className="text-sm text-muted-foreground">Total Amount</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Booking Items */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Select Items to Book</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item) => {
                const isSelected = selectedItems.includes(item.id);
                
                return (
                  <div 
                    key={item.id}
                    className={`p-4 rounded-lg border transition-colors ${
                      isSelected ? 'bg-primary/5 border-primary' : 'bg-muted/30'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => handleItemToggle(item.id)}
                        data-testid={`checkbox-${item.id}`}
                      />
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{item.name}</h4>
                          <Badge variant="outline" className="capitalize">
                            {item.type}
                          </Badge>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-2">
                          {item.details}
                        </p>
                        
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center gap-1 text-muted-foreground">
                            <Calendar className="w-3 h-3" />
                            {item.date}
                          </span>
                          <span className="font-semibold flex items-center gap-1">
                            <IndianRupee className="w-3 h-3" />
                            {item.cost.toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* Payment Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payment Method</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="card" id="card" />
                  <Label htmlFor="card" className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    Credit/Debit Card
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="upi" id="upi" />
                  <Label htmlFor="upi" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    UPI
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="wallet" id="wallet" />
                  <Label htmlFor="wallet" className="flex items-center gap-2">
                    <IndianRupee className="w-4 h-4" />
                    Digital Wallet
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Total & Book */}
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{selectedTotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Service Fee</span>
                    <span>₹{Math.round(selectedTotal * 0.05).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Taxes</span>
                    <span>₹{Math.round(selectedTotal * 0.12).toLocaleString('en-IN')}</span>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span>₹{Math.round(selectedTotal * 1.17).toLocaleString('en-IN')}</span>
                </div>

                <Button 
                  onClick={handleBooking}
                  disabled={selectedItems.length === 0 || isProcessing}
                  className="w-full"
                  size="lg"
                  data-testid="button-confirm-booking"
                >
                  {isProcessing ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Shield className="w-4 h-4 mr-2" />
                      Confirm Booking
                    </>
                  )}
                </Button>

                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Shield className="w-3 h-3" />
                  Secure payment protected by encryption
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Support */}
          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium mb-2">Need Help?</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="w-3 h-3" />
                  +91 1800-XXX-XXXX
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="w-3 h-3" />
                  support@aitripplanner.com
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}