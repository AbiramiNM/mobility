import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { IndianRupee, PieChart, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";

interface CostCategory {
  name: string;
  amount: number;
  percentage: number;
  color: string;
  items: { name: string; cost: number }[];
}

interface CostBreakdownProps {
  categories: CostCategory[];
  totalBudget: number;
  targetBudget: number;
  onOptimize?: () => void;
}

export default function CostBreakdown({ 
  categories, 
  totalBudget, 
  targetBudget, 
  onOptimize 
}: CostBreakdownProps) {
  
  const budgetStatus = totalBudget <= targetBudget ? 'within' : 'over';
  const budgetDifference = Math.abs(totalBudget - targetBudget);
  const budgetPercentage = (totalBudget / targetBudget) * 100;

  const handleOptimize = () => {
    console.log("Optimize budget clicked");
    onOptimize?.();
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* Budget Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="w-5 h-5" />
            Cost Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Budget Status */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div>
                <p className="text-sm text-muted-foreground">Total Cost</p>
                <p className="text-2xl font-bold flex items-center gap-1">
                  <IndianRupee className="w-5 h-5" />
                  {totalBudget.toLocaleString('en-IN')}
                </p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 mb-1">
                  {budgetStatus === 'within' ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                  )}
                  <Badge variant={budgetStatus === 'within' ? 'default' : 'destructive'}>
                    {budgetStatus === 'within' ? 'Within Budget' : 'Over Budget'}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {budgetStatus === 'within' ? '₹' : '+₹'}{budgetDifference.toLocaleString('en-IN')} 
                  {budgetStatus === 'within' ? ' under' : ' over'} budget
                </p>
              </div>
            </div>

            {/* Budget Progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Budget Usage</span>
                <span>{budgetPercentage.toFixed(1)}%</span>
              </div>
              <Progress 
                value={Math.min(budgetPercentage, 100)} 
                className="w-full"
                data-testid="budget-progress"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>₹0</span>
                <span>Target: ₹{targetBudget.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Optimize Button */}
            {budgetStatus === 'over' && (
              <Button 
                onClick={handleOptimize} 
                className="w-full" 
                variant="outline"
                data-testid="button-optimize-budget"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Optimize Budget
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Category Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Expense Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {categories.map((category) => (
              <div key={category.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: category.color }}
                    />
                    <span className="font-medium">{category.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">₹{category.amount.toLocaleString('en-IN')}</p>
                    <p className="text-xs text-muted-foreground">{category.percentage}%</p>
                  </div>
                </div>
                
                <Progress 
                  value={category.percentage} 
                  className="w-full h-2"
                  style={{ 
                    '--progress-foreground': category.color 
                  } as React.CSSProperties}
                />

                {/* Category Items */}
                <div className="ml-5 space-y-1">
                  {category.items.map((item, index) => (
                    <div 
                      key={index} 
                      className="flex justify-between text-sm text-muted-foreground"
                      data-testid={`cost-item-${category.name.toLowerCase()}-${index}`}
                    >
                      <span>{item.name}</span>
                      <span>₹{item.cost.toLocaleString('en-IN')}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-primary">
              ₹{Math.round(totalBudget / 7).toLocaleString('en-IN')}
            </p>
            <p className="text-sm text-muted-foreground">Per Day</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-primary">
              {categories.length}
            </p>
            <p className="text-sm text-muted-foreground">Categories</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}