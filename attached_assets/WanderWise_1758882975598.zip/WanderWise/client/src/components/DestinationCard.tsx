import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, IndianRupee, Star } from "lucide-react";

interface DestinationCardProps {
  title: string;
  location: string;
  image: string;
  duration: string;
  price: number;
  rating: number;
  tags: string[];
  description: string;
  onClick?: () => void;
}

export default function DestinationCard({
  title,
  location,
  image,
  duration,
  price,
  rating,
  tags,
  description,
  onClick
}: DestinationCardProps) {
  const handleCardClick = () => {
    console.log(`Destination card clicked: ${title}`);
    onClick?.();
  };

  return (
    <Card className="overflow-hidden hover-elevate cursor-pointer group" onClick={handleCardClick}>
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute top-3 left-3">
          <Badge className="bg-background/90 text-foreground">
            <Star className="w-3 h-3 mr-1 fill-current" />
            {rating}
          </Badge>
        </div>
        <div className="absolute top-3 right-3">
          <Badge variant="secondary" className="bg-background/90">
            <IndianRupee className="w-3 h-3 mr-1" />
            {price.toLocaleString('en-IN')}
          </Badge>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-lg line-clamp-1" data-testid={`destination-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {title}
            </h3>
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {location}
            </p>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{duration}</span>
          </div>

          <div className="flex flex-wrap gap-1">
            {tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
            {tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{tags.length - 3} more
              </Badge>
            )}
          </div>

          <Button 
            className="w-full mt-3" 
            variant="outline"
            data-testid={`button-view-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}