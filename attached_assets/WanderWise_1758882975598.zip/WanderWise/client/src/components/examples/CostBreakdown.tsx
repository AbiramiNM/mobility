import CostBreakdown from '../CostBreakdown';

export default function CostBreakdownExample() {
  //todo: remove mock functionality
  const mockCategories = [
    {
      name: "Accommodation",
      amount: 15000,
      percentage: 40,
      color: "#3b82f6",
      items: [
        { name: "Heritage Hotel (3 nights)", cost: 9000 },
        { name: "Houseboat (2 nights)", cost: 6000 }
      ]
    },
    {
      name: "Food & Dining", 
      amount: 8000,
      percentage: 21,
      color: "#f59e0b",
      items: [
        { name: "Local Restaurant Meals", cost: 4500 },
        { name: "Street Food Tours", cost: 2000 },
        { name: "Hotel Breakfast", cost: 1500 }
      ]
    },
    {
      name: "Transportation",
      amount: 7500, 
      percentage: 20,
      color: "#10b981",
      items: [
        { name: "Airport Transfers", cost: 3000 },
        { name: "Local Taxi/Auto", cost: 2500 },
        { name: "Train Tickets", cost: 2000 }
      ]
    },
    {
      name: "Activities & Tours",
      amount: 5500,
      percentage: 15,
      color: "#8b5cf6", 
      items: [
        { name: "Guided Heritage Tours", cost: 3000 },
        { name: "Backwater Cruise", cost: 1500 },
        { name: "Cultural Performances", cost: 1000 }
      ]
    },
    {
      name: "Miscellaneous",
      amount: 1500,
      percentage: 4,
      color: "#ef4444",
      items: [
        { name: "Shopping & Souvenirs", cost: 800 },
        { name: "Tips & Gratuities", cost: 400 },
        { name: "Emergency Fund", cost: 300 }
      ]
    }
  ];

  return (
    <div className="p-8 bg-background">
      <CostBreakdown
        categories={mockCategories}
        totalBudget={37500}
        targetBudget={35000}
        onOptimize={() => console.log("Optimize budget functionality")}
      />
    </div>
  );
}