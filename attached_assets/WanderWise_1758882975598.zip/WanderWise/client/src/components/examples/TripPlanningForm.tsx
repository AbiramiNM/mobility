import TripPlanningForm from '../TripPlanningForm';

export default function TripPlanningFormExample() {
  return (
    <div className="p-8 bg-background">
      <TripPlanningForm 
        onSubmit={(preferences) => console.log("Form submitted:", preferences)} 
      />
    </div>
  );
}