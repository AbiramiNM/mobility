import HeroSection from '../HeroSection';

export default function HeroSectionExample() {
  return (
    <HeroSection onStartPlanning={() => console.log("Hero CTA clicked")} />
  );
}