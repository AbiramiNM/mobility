import ItineraryDisplay from '../ItineraryDisplay';

export default function ItineraryDisplayExample() {
  //todo: remove mock functionality
  const mockItinerary = [
    {
      day: 1,
      date: "March 15, 2024",
      title: "Arrival in Kochi",
      totalCost: 8500,
      activities: [
        {
          id: "1-1",
          time: "10:00",
          title: "Arrival at Kochi Airport",
          description: "Land at Cochin International Airport and transfer to hotel",
          duration: "2 hours",
          cost: 1500,
          type: "transport" as const,
          location: "Kochi Airport"
        },
        {
          id: "1-2", 
          time: "14:00",
          title: "Traditional Kerala Lunch",
          description: "Authentic Kerala thali at a local restaurant",
          duration: "1 hour",
          cost: 500,
          type: "meal" as const,
          location: "Fort Kochi"
        },
        {
          id: "1-3",
          time: "16:00", 
          title: "Fort Kochi Walking Tour",
          description: "Explore Chinese fishing nets, colonial architecture, and spice markets",
          duration: "3 hours",
          cost: 1500,
          type: "activity" as const,
          location: "Fort Kochi"
        },
        {
          id: "1-4",
          time: "20:00",
          title: "Hotel Check-in",
          description: "Boutique heritage hotel in the heart of Fort Kochi",
          duration: "Overnight",
          cost: 5000,
          type: "accommodation" as const,
          location: "Fort Kochi"
        }
      ]
    },
    {
      day: 2,
      date: "March 16, 2024", 
      title: "Backwater Cruise",
      totalCost: 12000,
      activities: [
        {
          id: "2-1",
          time: "09:00",
          title: "Houseboat Check-in", 
          description: "Traditional Kerala houseboat with modern amenities",
          duration: "Full day",
          cost: 8000,
          type: "accommodation" as const,
          location: "Alleppey"
        },
        {
          id: "2-2",
          time: "12:00",
          title: "Backwater Cruise & Lunch",
          description: "Scenic cruise through palm-fringed canals with fresh seafood",
          duration: "4 hours", 
          cost: 2500,
          type: "activity" as const,
          location: "Alleppey Backwaters"
        },
        {
          id: "2-3",
          time: "18:00",
          title: "Traditional Kerala Dinner",
          description: "Local fish curry and appam prepared onboard",
          duration: "1 hour",
          cost: 1500,
          type: "meal" as const,
          location: "Houseboat"
        }
      ]
    }
  ];

  return (
    <div className="p-8 bg-background">
      <ItineraryDisplay
        itinerary={mockItinerary}
        totalBudget={20500}
        onEdit={(dayIndex, activityId) => console.log(`Edit activity ${activityId} on day ${dayIndex + 1}`)}
        onShare={() => console.log("Share itinerary")}
        onDownload={() => console.log("Download itinerary")}
      />
    </div>
  );
}