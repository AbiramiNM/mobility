import DestinationCard from '../DestinationCard';
import keralaImage from "@assets/generated_images/Kerala_backwaters_destination_65eee440.png";
import rajasthanImage from "@assets/generated_images/Rajasthan_palace_heritage_f36a58ae.png";
import goaImage from "@assets/generated_images/Goa_beach_sunset_0ca5c8f2.png";

export default function DestinationCardExample() {
  //todo: remove mock functionality
  const mockDestinations = [
    {
      title: "Kerala Backwaters Experience",
      location: "Alleppey, Kerala",
      image: keralaImage,
      duration: "5-7 days",
      price: 25000,
      rating: 4.8,
      tags: ["Nature", "Relaxation", "Houseboat", "Ayurveda"],
      description: "Peaceful journey through palm-fringed canals with traditional houseboat stays and authentic Kerala cuisine."
    },
    {
      title: "Rajasthan Royal Heritage",
      location: "Jaipur, Rajasthan", 
      image: rajasthanImage,
      duration: "7-10 days",
      price: 45000,
      rating: 4.9,
      tags: ["Heritage", "Culture", "Palaces", "History"],
      description: "Explore magnificent palaces, vibrant markets, and rich Rajasthani culture in the Pink City."
    },
    {
      title: "Goa Beach Paradise",
      location: "Goa",
      image: goaImage,
      duration: "4-6 days", 
      price: 20000,
      rating: 4.6,
      tags: ["Beaches", "Nightlife", "Portuguese", "Water Sports"],
      description: "Sun-soaked beaches, vibrant nightlife, and Portuguese colonial charm in India's favorite beach destination."
    }
  ];

  return (
    <div className="p-8 bg-background">
      <h2 className="text-2xl font-semibold mb-6">Popular Destinations</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockDestinations.map((destination) => (
          <DestinationCard
            key={destination.title}
            {...destination}
            onClick={() => console.log(`Clicked on ${destination.title}`)}
          />
        ))}
      </div>
    </div>
  );
}