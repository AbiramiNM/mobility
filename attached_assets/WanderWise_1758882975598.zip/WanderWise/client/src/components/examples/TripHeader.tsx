import TripHeader from '../TripHeader';

export default function TripHeaderExample() {
  return (
    <TripHeader 
      onLanguageToggle={() => console.log("Language toggle clicked")}
      currentLanguage="EN"
    />
  );
}