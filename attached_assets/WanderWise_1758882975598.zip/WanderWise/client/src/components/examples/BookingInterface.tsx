import BookingInterface from '../BookingInterface';

export default function BookingInterfaceExample() {
  //todo: remove mock functionality
  const mockItems = [
    {
      id: "hotel-1",
      type: "accommodation" as const,
      name: "Heritage Boutique Hotel",
      details: "3 nights in Fort Kochi with breakfast included",
      cost: 9000,
      date: "Mar 15-18, 2024",
      selected: true
    },
    {
      id: "houseboat-1", 
      type: "accommodation" as const,
      name: "Traditional Kerala Houseboat",
      details: "2 nights in Alleppey backwaters with all meals",
      cost: 8000,
      date: "Mar 16-17, 2024", 
      selected: true
    },
    {
      id: "transfer-1",
      type: "transport" as const,
      name: "Airport Transfer",
      details: "Private car from Kochi Airport to hotel",
      cost: 1500,
      date: "Mar 15, 2024",
      selected: true
    },
    {
      id: "tour-1",
      type: "activity" as const,
      name: "Fort Kochi Heritage Walk",
      details: "3-hour guided tour with local expert",
      cost: 1500,
      date: "Mar 15, 2024",
      selected: false
    },
    {
      id: "cruise-1",
      type: "activity" as const,
      name: "Backwater Cruise",
      details: "4-hour scenic cruise with traditional lunch",
      cost: 2500,
      date: "Mar 16, 2024",
      selected: true
    }
  ];

  return (
    <div className="p-8 bg-background">
      <BookingInterface
        items={mockItems}
        totalAmount={22500}
        onBook={(selectedItems, paymentMethod) => 
          console.log("Booking confirmed:", { selectedItems, paymentMethod })
        }
      />
    </div>
  );
}