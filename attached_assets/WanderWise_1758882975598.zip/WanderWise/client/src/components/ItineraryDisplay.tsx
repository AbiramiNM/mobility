import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Clock, MapPin, IndianRupee, Calendar, Utensils, Bed, Car, Camera, Share, Download, Edit } from "lucide-react";

interface Activity {
  id: string;
  time: string;
  title: string;
  description: string;
  duration: string;
  cost: number;
  type: "accommodation" | "transport" | "activity" | "meal";
  location: string;
}

interface DayItinerary {
  day: number;
  date: string;
  title: string;
  activities: Activity[];
  totalCost: number;
}

interface ItineraryDisplayProps {
  itinerary: DayItinerary[];
  totalBudget: number;
  onEdit?: (dayIndex: number, activityId: string) => void;
  onShare?: () => void;
  onDownload?: () => void;
}

export default function ItineraryDisplay({ 
  itinerary, 
  totalBudget, 
  onEdit, 
  onShare, 
  onDownload 
}: ItineraryDisplayProps) {
  
  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'accommodation': return <Bed className="w-4 h-4" />;
      case 'transport': return <Car className="w-4 h-4" />;
      case 'meal': return <Utensils className="w-4 h-4" />;
      default: return <Camera className="w-4 h-4" />;
    }
  };

  const getActivityColor = (type: Activity['type']) => {
    switch (type) {
      case 'accommodation': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'transport': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'meal': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      default: return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header with Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Your AI-Generated Itinerary
              </CardTitle>
              <p className="text-muted-foreground mt-1">
                {itinerary.length} days • Total Budget: ₹{totalBudget.toLocaleString('en-IN')}
              </p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={onShare}
                data-testid="button-share-itinerary"
              >
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={onDownload}
                data-testid="button-download-itinerary"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Daily Itinerary */}
      {itinerary.map((day, dayIndex) => (
        <Card key={day.day} className="overflow-hidden">
          <CardHeader className="bg-muted/50">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Day {day.day}</CardTitle>
                <p className="text-sm text-muted-foreground">{day.date} • {day.title}</p>
              </div>
              <Badge variant="secondary">
                <IndianRupee className="w-3 h-3 mr-1" />
                {day.totalCost.toLocaleString('en-IN')}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            {day.activities.map((activity, activityIndex) => (
              <div key={activity.id}>
                <div className="p-4 hover-elevate group">
                  <div className="flex items-start gap-4">
                    {/* Time */}
                    <div className="flex-shrink-0 w-16 text-center">
                      <Badge variant="outline" className="text-xs">
                        {activity.time}
                      </Badge>
                    </div>

                    {/* Activity Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <Badge className={getActivityColor(activity.type)}>
                            {getActivityIcon(activity.type)}
                            <span className="ml-1 capitalize">{activity.type}</span>
                          </Badge>
                          <h4 className="font-medium truncate" data-testid={`activity-${activity.id}`}>
                            {activity.title}
                          </h4>
                        </div>
                        
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge variant="secondary">
                            ₹{activity.cost.toLocaleString('en-IN')}
                          </Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onEdit?.(dayIndex, activity.id)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                            data-testid={`button-edit-${activity.id}`}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground mb-2">
                        {activity.description}
                      </p>

                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {activity.duration}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {activity.location}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {activityIndex < day.activities.length - 1 && (
                  <Separator className="mx-4" />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      {/* Summary */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Trip Summary</h3>
              <p className="text-sm text-muted-foreground">
                {itinerary.length} days of amazing experiences across India
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold">₹{totalBudget.toLocaleString('en-IN')}</p>
              <p className="text-sm text-muted-foreground">Total per person</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}