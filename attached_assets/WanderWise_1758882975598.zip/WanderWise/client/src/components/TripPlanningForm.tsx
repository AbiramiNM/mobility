import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Users, Heart, Mountain, Building2, Utensils, Sparkles } from "lucide-react";
import { useState } from "react";

interface TripPreferences {
  destination: string;
  duration: number;
  budget: number;
  travelers: number;
  interests: string[];
  startDate: string;
}

interface TripPlanningFormProps {
  onSubmit?: (preferences: TripPreferences) => void;
}

export default function TripPlanningForm({ onSubmit }: TripPlanningFormProps) {
  const [preferences, setPreferences] = useState<TripPreferences>({
    destination: "",
    duration: 7,
    budget: 50000,
    travelers: 2,
    interests: [],
    startDate: ""
  });

  const interestOptions = [
    { id: "heritage", label: "Cultural Heritage", icon: Building2 },
    { id: "adventure", label: "Adventure", icon: Mountain },
    { id: "cuisine", label: "Local Cuisine", icon: Utensils },
    { id: "wellness", label: "Wellness & Spa", icon: Heart },
    { id: "nightlife", label: "Nightlife", icon: Sparkles },
    { id: "nature", label: "Nature & Wildlife", icon: Mountain },
  ];

  const destinations = [
    "Kerala - Backwaters & Beaches",
    "Rajasthan - Palaces & Culture", 
    "Goa - Beaches & Nightlife",
    "Himachal Pradesh - Mountains & Adventure",
    "Tamil Nadu - Temples & Heritage",
    "Karnataka - Tech Cities & Nature",
    "Maharashtra - Cities & Heritage",
    "West Bengal - Culture & Literature"
  ];

  const toggleInterest = (interestId: string) => {
    setPreferences(prev => ({
      ...prev,
      interests: prev.interests.includes(interestId)
        ? prev.interests.filter(id => id !== interestId)
        : [...prev.interests, interestId]
    }));
  };

  const handleSubmit = () => {
    console.log("Trip preferences:", preferences);
    onSubmit?.(preferences);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          Plan Your Trip with AI
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Destination Selection */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Preferred Destination
          </Label>
          <Select 
            value={preferences.destination} 
            onValueChange={(value) => setPreferences(prev => ({...prev, destination: value}))}
          >
            <SelectTrigger data-testid="select-destination">
              <SelectValue placeholder="Choose your destination in India" />
            </SelectTrigger>
            <SelectContent>
              {destinations.map((dest) => (
                <SelectItem key={dest} value={dest}>{dest}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Duration and Travelers */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Trip Duration: {preferences.duration} days
            </Label>
            <Slider
              value={[preferences.duration]}
              onValueChange={([value]) => setPreferences(prev => ({...prev, duration: value}))}
              max={30}
              min={3}
              step={1}
              className="w-full"
              data-testid="slider-duration"
            />
          </div>
          
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Number of Travelers
            </Label>
            <Select 
              value={preferences.travelers.toString()} 
              onValueChange={(value) => setPreferences(prev => ({...prev, travelers: parseInt(value)}))}
            >
              <SelectTrigger data-testid="select-travelers">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Solo Traveler</SelectItem>
                <SelectItem value="2">2 People</SelectItem>
                <SelectItem value="3">3 People</SelectItem>
                <SelectItem value="4">4 People</SelectItem>
                <SelectItem value="5">5+ People</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Budget */}
        <div className="space-y-2">
          <Label>Budget per Person: ₹{preferences.budget.toLocaleString('en-IN')}</Label>
          <Slider
            value={[preferences.budget]}
            onValueChange={([value]) => setPreferences(prev => ({...prev, budget: value}))}
            max={200000}
            min={10000}
            step={5000}
            className="w-full"
            data-testid="slider-budget"
          />
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>₹10K</span>
            <span>₹2L+</span>
          </div>
        </div>

        {/* Interests */}
        <div className="space-y-3">
          <Label>What interests you?</Label>
          <div className="grid grid-cols-2 gap-2">
            {interestOptions.map((interest) => {
              const Icon = interest.icon;
              const isSelected = preferences.interests.includes(interest.id);
              
              return (
                <Badge
                  key={interest.id}
                  variant={isSelected ? "default" : "outline"}
                  className={`p-3 cursor-pointer hover-elevate ${isSelected ? 'bg-primary text-primary-foreground' : ''}`}
                  onClick={() => toggleInterest(interest.id)}
                  data-testid={`interest-${interest.id}`}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {interest.label}
                </Badge>
              );
            })}
          </div>
        </div>

        {/* Start Date */}
        <div className="space-y-2">
          <Label>Preferred Start Date</Label>
          <Input
            type="date"
            value={preferences.startDate}
            onChange={(e) => setPreferences(prev => ({...prev, startDate: e.target.value}))}
            data-testid="input-start-date"
          />
        </div>

        {/* Submit Button */}
        <Button 
          onClick={handleSubmit} 
          className="w-full" 
          size="lg"
          data-testid="button-generate-itinerary"
          disabled={!preferences.destination || preferences.interests.length === 0}
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Generate AI Itinerary
        </Button>
      </CardContent>
    </Card>
  );
}