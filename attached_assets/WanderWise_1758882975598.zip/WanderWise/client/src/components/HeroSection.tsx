import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Clock, Star, Sparkles } from "lucide-react";
import heroImage from "@assets/generated_images/India_Taj_Mahal_hero_bd2a9ea7.png";

interface HeroSectionProps {
  onStartPlanning?: () => void;
}

export default function HeroSection({ onStartPlanning }: HeroSectionProps) {
  const handleStartPlanning = () => {
    console.log("Start planning clicked");
    onStartPlanning?.();
  };

  return (
    <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="Beautiful India destination" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Plan Your Perfect
            <span className="text-primary-foreground block mt-2">
              Indian Adventure
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Let AI create personalized itineraries tailored to your budget, interests, and time. 
            From cultural heritage to adventure sports - discover India your way.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              onClick={handleStartPlanning}
              data-testid="button-start-planning"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 py-3"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Start Planning with AI
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              data-testid="button-view-examples"
              className="bg-background/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
            >
              View Example Trips
            </Button>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
            <Card className="bg-background/10 backdrop-blur-sm border-white/20 p-6">
              <MapPin className="w-8 h-8 text-primary mb-3 mx-auto" />
              <h3 className="font-semibold text-white mb-2">Smart Destinations</h3>
              <p className="text-sm text-white/80">AI-curated places based on your interests and budget</p>
            </Card>
            
            <Card className="bg-background/10 backdrop-blur-sm border-white/20 p-6">
              <Clock className="w-8 h-8 text-primary mb-3 mx-auto" />
              <h3 className="font-semibold text-white mb-2">Real-time Updates</h3>
              <p className="text-sm text-white/80">Dynamic itinerary adjustments for weather and events</p>
            </Card>
            
            <Card className="bg-background/10 backdrop-blur-sm border-white/20 p-6">
              <Star className="w-8 h-8 text-primary mb-3 mx-auto" />
              <h3 className="font-semibold text-white mb-2">One-Click Booking</h3>
              <p className="text-sm text-white/80">Seamless reservations and payments all in one place</p>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}