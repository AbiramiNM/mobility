import { Button } from "@/components/ui/button";
import { Globe, Menu, Moon, Sun, User } from "lucide-react";
import { useState } from "react";

interface TripHeaderProps {
  onLanguageToggle?: () => void;
  currentLanguage?: string;
}

export default function TripHeader({ onLanguageToggle, currentLanguage = "EN" }: TripHeaderProps) {
  const [isDark, setIsDark] = useState(false);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
    console.log("Theme toggled:", !isDark ? "dark" : "light");
  };

  const handleNavClick = (section: string) => {
    console.log(`Navigate to ${section}`);
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Globe className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-bold">AI Trip Planner</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Button 
              variant="ghost" 
              onClick={() => handleNavClick("destinations")}
              data-testid="nav-destinations"
            >
              Destinations
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => handleNavClick("how-it-works")}
              data-testid="nav-how-it-works"
            >
              How It Works
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => handleNavClick("pricing")}
              data-testid="nav-pricing"
            >
              Pricing
            </Button>
          </nav>

          {/* Controls */}
          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={onLanguageToggle}
              data-testid="button-language-toggle"
              className="hidden sm:flex"
            >
              {currentLanguage}
            </Button>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            {/* User Profile */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleNavClick("profile")}
              data-testid="button-user-profile"
            >
              <User className="h-4 w-4" />
            </Button>

            {/* Mobile Menu */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => console.log("Mobile menu toggled")}
              data-testid="button-mobile-menu"
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}