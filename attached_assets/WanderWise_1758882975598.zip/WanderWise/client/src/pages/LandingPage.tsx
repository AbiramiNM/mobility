import { useState } from "react";
import TripHeader from "@/components/TripHeader";
import HeroSection from "@/components/HeroSection";
import TripPlanningForm from "@/components/TripPlanningForm";
import DestinationCard from "@/components/DestinationCard";
import ItineraryDisplay from "@/components/ItineraryDisplay";
import CostBreakdown from "@/components/CostBreakdown";
import BookingInterface from "@/components/BookingInterface";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Star, Users, Clock, Globe } from "lucide-react";

// Import destination images
import keralaImage from "@assets/generated_images/Kerala_backwaters_destination_65eee440.png";
import rajasthanImage from "@assets/generated_images/Rajasthan_palace_heritage_f36a58ae.png";
import goaImage from "@assets/generated_images/Goa_beach_sunset_0ca5c8f2.png";
import himalayanImage from "@assets/generated_images/Himalayan_adventure_trekking_d27f1c40.png";

type ViewState = 'landing' | 'planning' | 'itinerary' | 'booking';

export default function LandingPage() {
  const [currentView, setCurrentView] = useState<ViewState>('landing');
  const [currentLanguage, setCurrentLanguage] = useState("EN");

  //todo: remove mock functionality
  const popularDestinations = [
    {
      title: "Kerala Backwaters Experience",
      location: "Alleppey, Kerala",
      image: keralaImage,
      duration: "5-7 days",
      price: 25000,
      rating: 4.8,
      tags: ["Nature", "Relaxation", "Houseboat", "Ayurveda"],
      description: "Peaceful journey through palm-fringed canals with traditional houseboat stays and authentic Kerala cuisine."
    },
    {
      title: "Rajasthan Royal Heritage",
      location: "Jaipur, Rajasthan", 
      image: rajasthanImage,
      duration: "7-10 days",
      price: 45000,
      rating: 4.9,
      tags: ["Heritage", "Culture", "Palaces", "History"],
      description: "Explore magnificent palaces, vibrant markets, and rich Rajasthani culture in the Pink City."
    },
    {
      title: "Goa Beach Paradise",
      location: "Goa",
      image: goaImage,
      duration: "4-6 days", 
      price: 20000,
      rating: 4.6,
      tags: ["Beaches", "Nightlife", "Portuguese", "Water Sports"],
      description: "Sun-soaked beaches, vibrant nightlife, and Portuguese colonial charm."
    },
    {
      title: "Himalayan Adventure",
      location: "Himachal Pradesh",
      image: himalayanImage,
      duration: "8-12 days",
      price: 35000,
      rating: 4.7,
      tags: ["Adventure", "Trekking", "Mountains", "Nature"],
      description: "Thrilling mountain adventures with breathtaking Himalayan views and challenging treks."
    }
  ];

  const mockItinerary = [
    {
      day: 1,
      date: "March 15, 2024",
      title: "Arrival in Kochi",
      totalCost: 8500,
      activities: [
        {
          id: "1-1",
          time: "10:00",
          title: "Arrival at Kochi Airport",
          description: "Land at Cochin International Airport and transfer to hotel",
          duration: "2 hours",
          cost: 1500,
          type: "transport" as const,
          location: "Kochi Airport"
        },
        {
          id: "1-2", 
          time: "14:00",
          title: "Traditional Kerala Lunch",
          description: "Authentic Kerala thali at a local restaurant",
          duration: "1 hour",
          cost: 500,
          type: "meal" as const,
          location: "Fort Kochi"
        },
        {
          id: "1-3",
          time: "16:00", 
          title: "Fort Kochi Walking Tour",
          description: "Explore Chinese fishing nets, colonial architecture, and spice markets",
          duration: "3 hours",
          cost: 1500,
          type: "activity" as const,
          location: "Fort Kochi"
        },
        {
          id: "1-4",
          time: "20:00",
          title: "Hotel Check-in",
          description: "Boutique heritage hotel in the heart of Fort Kochi",
          duration: "Overnight",
          cost: 5000,
          type: "accommodation" as const,
          location: "Fort Kochi"
        }
      ]
    },
    {
      day: 2,
      date: "March 16, 2024", 
      title: "Backwater Cruise",
      totalCost: 12000,
      activities: [
        {
          id: "2-1",
          time: "09:00",
          title: "Houseboat Check-in", 
          description: "Traditional Kerala houseboat with modern amenities",
          duration: "Full day",
          cost: 8000,
          type: "accommodation" as const,
          location: "Alleppey"
        },
        {
          id: "2-2",
          time: "12:00",
          title: "Backwater Cruise & Lunch",
          description: "Scenic cruise through palm-fringed canals with fresh seafood",
          duration: "4 hours", 
          cost: 2500,
          type: "activity" as const,
          location: "Alleppey Backwaters"
        },
        {
          id: "2-3",
          time: "18:00",
          title: "Traditional Kerala Dinner",
          description: "Local fish curry and appam prepared onboard",
          duration: "1 hour",
          cost: 1500,
          type: "meal" as const,
          location: "Houseboat"
        }
      ]
    }
  ];

  const mockCostCategories = [
    {
      name: "Accommodation",
      amount: 15000,
      percentage: 40,
      color: "#3b82f6",
      items: [
        { name: "Heritage Hotel (3 nights)", cost: 9000 },
        { name: "Houseboat (2 nights)", cost: 6000 }
      ]
    },
    {
      name: "Food & Dining", 
      amount: 8000,
      percentage: 21,
      color: "#f59e0b",
      items: [
        { name: "Local Restaurant Meals", cost: 4500 },
        { name: "Street Food Tours", cost: 2000 },
        { name: "Hotel Breakfast", cost: 1500 }
      ]
    },
    {
      name: "Transportation",
      amount: 7500, 
      percentage: 20,
      color: "#10b981",
      items: [
        { name: "Airport Transfers", cost: 3000 },
        { name: "Local Taxi/Auto", cost: 2500 },
        { name: "Train Tickets", cost: 2000 }
      ]
    },
    {
      name: "Activities & Tours",
      amount: 5500,
      percentage: 15,
      color: "#8b5cf6", 
      items: [
        { name: "Guided Heritage Tours", cost: 3000 },
        { name: "Backwater Cruise", cost: 1500 },
        { name: "Cultural Performances", cost: 1000 }
      ]
    },
    {
      name: "Miscellaneous",
      amount: 1500,
      percentage: 4,
      color: "#ef4444",
      items: [
        { name: "Shopping & Souvenirs", cost: 800 },
        { name: "Tips & Gratuities", cost: 400 },
        { name: "Emergency Fund", cost: 300 }
      ]
    }
  ];

  const mockBookingItems = [
    {
      id: "hotel-1",
      type: "accommodation" as const,
      name: "Heritage Boutique Hotel",
      details: "3 nights in Fort Kochi with breakfast included",
      cost: 9000,
      date: "Mar 15-18, 2024",
      selected: true
    },
    {
      id: "houseboat-1", 
      type: "accommodation" as const,
      name: "Traditional Kerala Houseboat",
      details: "2 nights in Alleppey backwaters with all meals",
      cost: 8000,
      date: "Mar 16-17, 2024", 
      selected: true
    },
    {
      id: "transfer-1",
      type: "transport" as const,
      name: "Airport Transfer",
      details: "Private car from Kochi Airport to hotel",
      cost: 1500,
      date: "Mar 15, 2024",
      selected: true
    },
    {
      id: "tour-1",
      type: "activity" as const,
      name: "Fort Kochi Heritage Walk",
      details: "3-hour guided tour with local expert",
      cost: 1500,
      date: "Mar 15, 2024",
      selected: false
    },
    {
      id: "cruise-1",
      type: "activity" as const,
      name: "Backwater Cruise",
      details: "4-hour scenic cruise with traditional lunch",
      cost: 2500,
      date: "Mar 16, 2024",
      selected: true
    }
  ];

  const handleLanguageToggle = () => {
    setCurrentLanguage(prev => prev === "EN" ? "हिं" : "EN");
    console.log("Language toggled to:", currentLanguage === "EN" ? "Hindi" : "English");
  };

  const handleStartPlanning = () => {
    setCurrentView('planning');
  };

  const handlePlanSubmit = (preferences: any) => {
    console.log("Planning form submitted:", preferences);
    setCurrentView('itinerary');
  };

  const handleViewBooking = () => {
    setCurrentView('booking');
  };

  const handleBookingComplete = (selectedItems: string[], paymentMethod: string) => {
    console.log("Booking completed:", { selectedItems, paymentMethod });
    alert("Booking confirmed! You'll receive a confirmation email shortly.");
    setCurrentView('landing');
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'planning':
        return (
          <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <Button 
                  variant="ghost" 
                  onClick={() => setCurrentView('landing')}
                  className="mb-4"
                  data-testid="button-back-to-landing"
                >
                  ← Back to Home
                </Button>
                <h1 className="text-3xl font-bold mb-4">Plan Your Perfect Trip</h1>
                <p className="text-muted-foreground">
                  Tell us your preferences and let AI create the perfect itinerary for you
                </p>
              </div>
              <TripPlanningForm onSubmit={handlePlanSubmit} />
            </div>
          </div>
        );

      case 'itinerary':
        return (
          <div className="container mx-auto px-4 py-16 space-y-8">
            <div className="text-center">
              <Button 
                variant="ghost" 
                onClick={() => setCurrentView('planning')}
                className="mb-4"
                data-testid="button-back-to-planning"
              >
                ← Back to Planning
              </Button>
              <h1 className="text-3xl font-bold mb-4">Your Personalized Itinerary</h1>
              <p className="text-muted-foreground">AI has crafted the perfect Kerala experience for you</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <ItineraryDisplay
                  itinerary={mockItinerary}
                  totalBudget={20500}
                  onEdit={(dayIndex, activityId) => console.log(`Edit activity ${activityId} on day ${dayIndex + 1}`)}
                  onShare={() => console.log("Share itinerary")}
                  onDownload={() => console.log("Download itinerary")}
                />
              </div>
              <div className="space-y-6">
                <CostBreakdown
                  categories={mockCostCategories}
                  totalBudget={37500}
                  targetBudget={35000}
                  onOptimize={() => console.log("Optimize budget functionality")}
                />
                <Card>
                  <CardContent className="p-6">
                    <Button 
                      onClick={handleViewBooking} 
                      className="w-full" 
                      size="lg"
                      data-testid="button-proceed-to-booking"
                    >
                      Proceed to Booking
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'booking':
        return (
          <div className="container mx-auto px-4 py-16">
            <div className="text-center mb-8">
              <Button 
                variant="ghost" 
                onClick={() => setCurrentView('itinerary')}
                className="mb-4"
                data-testid="button-back-to-itinerary"
              >
                ← Back to Itinerary
              </Button>
              <h1 className="text-3xl font-bold mb-4">Complete Your Booking</h1>
              <p className="text-muted-foreground">
                Secure your perfect Kerala adventure with one-click booking
              </p>
            </div>
            <BookingInterface
              items={mockBookingItems}
              totalAmount={22500}
              onBook={handleBookingComplete}
            />
          </div>
        );

      default:
        return (
          <>
            <HeroSection onStartPlanning={handleStartPlanning} />
            
            {/* Popular Destinations */}
            <section className="py-16 bg-muted/30">
              <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold mb-4">Popular Destinations</h2>
                  <p className="text-muted-foreground max-w-2xl mx-auto">
                    Discover India's most breathtaking destinations with AI-curated experiences
                    tailored to your interests and budget.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {popularDestinations.map((destination) => (
                    <DestinationCard
                      key={destination.title}
                      {...destination}
                      onClick={() => console.log(`Explore ${destination.title}`)}
                    />
                  ))}
                </div>
                
                <div className="text-center mt-12">
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={handleStartPlanning}
                    data-testid="button-plan-custom-trip"
                  >
                    Plan Custom Trip
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </section>

            {/* How It Works */}
            <section className="py-16">
              <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold mb-4">How It Works</h2>
                  <p className="text-muted-foreground max-w-2xl mx-auto">
                    Get your perfect Indian adventure in just three simple steps
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                  <Card className="text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-primary-foreground font-bold">1</span>
                      </div>
                      <h3 className="font-semibold mb-2">Share Your Preferences</h3>
                      <p className="text-sm text-muted-foreground">
                        Tell us your budget, interests, duration, and preferred destinations
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-primary-foreground font-bold">2</span>
                      </div>
                      <h3 className="font-semibold mb-2">AI Creates Your Itinerary</h3>
                      <p className="text-sm text-muted-foreground">
                        Our AI analyzes real-time data to craft your perfect personalized trip
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-primary-foreground font-bold">3</span>
                      </div>
                      <h3 className="font-semibold mb-2">Book & Travel</h3>
                      <p className="text-sm text-muted-foreground">
                        One-click booking for all accommodations, activities, and transport
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </section>

            {/* Stats Section */}
            <section className="py-16 bg-primary text-primary-foreground">
              <div className="container mx-auto px-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                  <div>
                    <p className="text-3xl font-bold mb-2">50K+</p>
                    <p className="text-sm opacity-90">Happy Travelers</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold mb-2">200+</p>
                    <p className="text-sm opacity-90">Destinations</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold mb-2">4.9</p>
                    <p className="text-sm opacity-90 flex items-center justify-center gap-1">
                      <Star className="w-4 h-4 fill-current" />
                      Average Rating
                    </p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold mb-2">24/7</p>
                    <p className="text-sm opacity-90">Support</p>
                  </div>
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="py-16">
              <div className="container mx-auto px-4 text-center">
                <Card className="max-w-2xl mx-auto">
                  <CardContent className="p-12">
                    <Globe className="w-16 h-16 text-primary mx-auto mb-6" />
                    <h2 className="text-2xl font-bold mb-4">Ready for Your Indian Adventure?</h2>
                    <p className="text-muted-foreground mb-8">
                      Join thousands of travelers who've discovered the perfect way to explore India
                      with AI-powered personalized itineraries.
                    </p>
                    <Button 
                      size="lg" 
                      onClick={handleStartPlanning}
                      data-testid="button-start-adventure"
                    >
                      Start Your Adventure
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </section>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TripHeader 
        onLanguageToggle={handleLanguageToggle}
        currentLanguage={currentLanguage}
      />
      {renderCurrentView()}
    </div>
  );
}