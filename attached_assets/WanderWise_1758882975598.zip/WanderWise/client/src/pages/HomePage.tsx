import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import TripHeader from "@/components/TripHeader";
import TripPlanningForm from "@/components/TripPlanningForm";
import ItineraryDisplay from "@/components/ItineraryDisplay";
import CostBreakdown from "@/components/CostBreakdown";
import BookingInterface from "@/components/BookingInterface";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  ChevronRight, 
  Calendar, 
  MapPin, 
  Sparkles, 
  User,
  LogOut,
  PlaneTakeoff
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

type ViewState = 'dashboard' | 'planning' | 'itinerary' | 'booking';

export default function HomePage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [selectedItinerary, setSelectedItinerary] = useState<any>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user's itineraries
  const { data: itinerariesData = [] } = useQuery({
    queryKey: ['/api/itineraries'],
    retry: false,
    enabled: isAuthenticated,
  });
  const itineraries = Array.isArray(itinerariesData) ? itinerariesData : [];

  // Create trip preferences mutation
  const tripPreferencesMutation = useMutation({
    mutationFn: async (preferences: any) => {
      return await apiRequest('/api/trip-preferences', 'POST', preferences);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Trip preferences saved! Generating itineraries...",
      });
      setCurrentView('itinerary');
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartPlanning = () => {
    setCurrentView('planning');
  };

  const handlePlanSubmit = (preferences: any) => {
    tripPreferencesMutation.mutate(preferences);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleLanguageToggle = () => {
    console.log("Language toggle - feature coming soon");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'planning':
        return (
          <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <Button 
                  variant="ghost" 
                  onClick={() => setCurrentView('dashboard')}
                  className="mb-4"
                  data-testid="button-back-to-dashboard"
                >
                  ← Back to Dashboard
                </Button>
                <h1 className="text-3xl font-bold mb-4">Plan Your Perfect Trip</h1>
                <p className="text-muted-foreground">
                  Tell us your preferences and let AI create multiple itinerary options for you
                </p>
              </div>
              <TripPlanningForm onSubmit={handlePlanSubmit} />
            </div>
          </div>
        );

      case 'itinerary':
        return (
          <div className="container mx-auto px-4 py-16 space-y-8">
            <div className="text-center">
              <Button 
                variant="ghost" 
                onClick={() => setCurrentView('dashboard')}
                className="mb-4"
                data-testid="button-back-to-dashboard"
              >
                ← Back to Dashboard
              </Button>
              <h1 className="text-3xl font-bold mb-4">AI-Generated Itinerary Options</h1>
              <p className="text-muted-foreground">Choose from multiple personalized travel plans</p>
            </div>
            
            <div className="text-center">
              <p className="text-muted-foreground">
                AI itinerary generation is being implemented. You'll see multiple options here soon!
              </p>
            </div>
          </div>
        );

      default:
        return (
          <div className="container mx-auto px-4 py-8">
            {/* Welcome Section */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold mb-2">Welcome back, {(user as any)?.firstName || 'Traveler'}!</h1>
                <p className="text-muted-foreground">Ready for your next adventure?</p>
              </div>
              <div className="flex items-center gap-4">
                <Avatar>
                  <AvatarImage src={(user as any)?.profileImageUrl || undefined} />
                  <AvatarFallback>
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <Button variant="outline" onClick={handleLogout} data-testid="button-logout">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <Card className="hover-elevate cursor-pointer" onClick={handleStartPlanning}>
                <CardContent className="p-6 text-center">
                  <Sparkles className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Plan New Trip</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Let AI create personalized itineraries based on your preferences
                  </p>
                  <Button className="w-full" data-testid="button-plan-new-trip">
                    Start Planning
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <Calendar className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Your Trips</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    View and manage your saved itineraries
                  </p>
                  <Badge variant="secondary">{itineraries.length} saved</Badge>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Destinations</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Explore popular destinations across India
                  </p>
                  <Button variant="outline" className="w-full">
                    Explore
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Itineraries */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PlaneTakeoff className="w-5 h-5" />
                  Recent Itineraries
                </CardTitle>
              </CardHeader>
              <CardContent>
                {itineraries.length > 0 ? (
                  <div className="space-y-4">
                    {itineraries.slice(0, 3).map((itinerary: any) => (
                      <div 
                        key={itinerary.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover-elevate cursor-pointer"
                        onClick={() => {
                          setSelectedItinerary(itinerary);
                          setCurrentView('itinerary');
                        }}
                      >
                        <div>
                          <h4 className="font-medium">{itinerary.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {itinerary.destination} • {itinerary.totalDays} days
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">₹{parseInt(itinerary.totalBudget).toLocaleString('en-IN')}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(itinerary.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <PlaneTakeoff className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h4 className="font-medium mb-2">No trips yet</h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Start planning your first adventure with AI
                    </p>
                    <Button onClick={handleStartPlanning} data-testid="button-start-first-trip">
                      Plan Your First Trip
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TripHeader 
        onLanguageToggle={handleLanguageToggle}
        currentLanguage="EN"
      />
      {renderCurrentView()}
    </div>
  );
}