# AI-Powered Trip Planner Design Guidelines

## Design Approach
**Reference-Based Approach** - Drawing inspiration from Airbnb and Booking.com for travel-focused UX patterns, combined with modern productivity tools like Linear for clean data presentation.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Light Mode: 14 88% 35% (Deep teal-blue for trust and wanderlust)
- Dark Mode: 14 75% 65% (Lighter teal for visibility)

**Secondary Colors:**
- Light: 45 85% 47% (Warm orange for energy and adventure)
- Dark: 45 80% 60% (Softer orange for dark backgrounds)

**Neutral Grays:**
- Light backgrounds: 220 13% 97%
- Dark backgrounds: 220 13% 8%
- Text: 220 9% 15% (light) / 220 9% 85% (dark)

### Typography
- **Primary Font:** Inter (Google Fonts) - Clean, modern readability
- **Accent Font:** Outfit (Google Fonts) - For headings and CTAs
- **Hierarchy:** 
  - H1: 2.5rem, font-bold
  - H2: 2rem, font-semibold  
  - H3: 1.5rem, font-medium
  - Body: 1rem, font-normal
  - Small: 0.875rem

### Layout System
**Spacing Units:** Tailwind 4, 6, 8, 12, 16 units
- Container max-width: 1200px
- Grid: 12-column responsive grid
- Card padding: p-6
- Section spacing: py-16
- Component gaps: gap-6

### Component Library

**Navigation:**
- Clean header with logo, main navigation, and user profile
- Sticky navigation on scroll with subtle shadow
- Mobile: Hamburger menu with slide-out drawer

**Forms:**
- Multi-step wizard for trip preferences
- Floating labels with smooth transitions
- Progress indicators for complex forms
- Smart defaults and auto-suggestions

**Cards:**
- Destination cards with rounded corners (rounded-xl)
- Subtle shadows (shadow-md) with hover elevation
- High-quality imagery with gradient overlays
- Price badges with contrasting backgrounds

**Data Displays:**
- Interactive timeline for itinerary visualization
- Cost breakdown with clear typography hierarchy
- Real-time status indicators (weather, availability)
- Shareable itinerary format with print-friendly styles

**CTAs & Buttons:**
- Primary: Solid teal background with white text
- Secondary: Outline style with teal border
- Destructive: Red tones for cancellations
- Rounded-lg with adequate padding (px-6 py-3)

### Key Screens Layout

**Landing Page:**
- Hero section with compelling travel imagery and AI positioning
- Feature highlights: Personalization, Real-time, Booking
- Social proof and testimonials
- Simple CTA to start planning

**Trip Planning Interface:**
- Left sidebar: Preferences form (budget, interests, duration)
- Center: Generated itinerary with day-by-day timeline
- Right panel: Cost breakdown and booking options
- Floating action button for quick modifications

**Itinerary Display:**
- Card-based layout for each day/activity
- Interactive map integration
- Collapsible details for accommodations/transport
- Easy sharing and export options

### Images
**Hero Image:** Large, inspiring travel destination photo with gradient overlay for text readability
**Destination Cards:** High-quality landscape/landmark photos
**Activity Icons:** Simple, consistent iconography for different trip themes
**User Avatars:** Circular profile images with subtle borders

### Interactions
- Smooth page transitions and micro-interactions
- Loading states for AI generation with progress indicators
- Hover effects on cards and buttons (subtle scale/shadow changes)
- Drag-and-drop for itinerary reordering
- Real-time updates without full page refreshes

### Accessibility
- Consistent dark mode throughout
- High contrast ratios for all text
- Keyboard navigation support
- Screen reader friendly labels
- Focus indicators for interactive elements

This design balances the excitement of travel planning with the efficiency needed for complex itinerary management, creating a trustworthy and inspiring user experience.