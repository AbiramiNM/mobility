import {
  users,
  tripPreferences,
  itineraries,
  type User,
  type UpsertUser,
  type TripPreferences,
  type InsertTripPreferences,
  type Itinerary,
  type InsertItinerary,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Storage interface with methods for authentication and trip planning
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Trip preferences operations
  saveTripPreferences(preferences: InsertTripPreferences): Promise<TripPreferences>;
  getTripPreferencesByUser(userId: string): Promise<TripPreferences[]>;
  
  // Itinerary operations
  saveItinerary(itinerary: InsertItinerary): Promise<Itinerary>;
  getItinerariesByUser(userId: string): Promise<Itinerary[]>;
  getItinerary(id: string): Promise<Itinerary | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Trip preferences operations
  async saveTripPreferences(preferences: InsertTripPreferences): Promise<TripPreferences> {
    const [saved] = await db
      .insert(tripPreferences)
      .values(preferences)
      .returning();
    return saved;
  }

  async getTripPreferencesByUser(userId: string): Promise<TripPreferences[]> {
    return await db
      .select()
      .from(tripPreferences)
      .where(eq(tripPreferences.userId, userId));
  }

  // Itinerary operations
  async saveItinerary(itinerary: InsertItinerary): Promise<Itinerary> {
    const [saved] = await db
      .insert(itineraries)
      .values(itinerary)
      .returning();
    return saved;
  }

  async getItinerariesByUser(userId: string): Promise<Itinerary[]> {
    return await db
      .select()
      .from(itineraries)
      .where(eq(itineraries.userId, userId));
  }

  async getItinerary(id: string): Promise<Itinerary | undefined> {
    const [itinerary] = await db
      .select()
      .from(itineraries)
      .where(eq(itineraries.id, id));
    return itinerary;
  }
}

export const storage = new DatabaseStorage();
