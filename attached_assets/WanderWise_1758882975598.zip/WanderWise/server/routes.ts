import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTripPreferencesSchema, insertItinerarySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Trip preferences routes
  app.post('/api/trip-preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = insertTripPreferencesSchema.parse({
        ...req.body,
        userId
      });
      
      const saved = await storage.saveTripPreferences(preferences);
      res.json(saved);
    } catch (error) {
      console.error("Error saving trip preferences:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid preferences data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save preferences" });
      }
    }
  });

  app.get('/api/trip-preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = await storage.getTripPreferencesByUser(userId);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching trip preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  // Itinerary routes
  app.post('/api/itineraries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const itinerary = insertItinerarySchema.parse({
        ...req.body,
        userId
      });
      
      const saved = await storage.saveItinerary(itinerary);
      res.json(saved);
    } catch (error) {
      console.error("Error saving itinerary:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid itinerary data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save itinerary" });
      }
    }
  });

  app.get('/api/itineraries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const itineraries = await storage.getItinerariesByUser(userId);
      res.json(itineraries);
    } catch (error) {
      console.error("Error fetching itineraries:", error);
      res.status(500).json({ message: "Failed to fetch itineraries" });
    }
  });

  app.get('/api/itineraries/:id', isAuthenticated, async (req: any, res) => {
    try {
      const itinerary = await storage.getItinerary(req.params.id);
      if (!itinerary) {
        return res.status(404).json({ message: "Itinerary not found" });
      }
      
      // Check if user owns this itinerary
      const userId = req.user.claims.sub;
      if (itinerary.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(itinerary);
    } catch (error) {
      console.error("Error fetching itinerary:", error);
      res.status(500).json({ message: "Failed to fetch itinerary" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
